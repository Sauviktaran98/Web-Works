<?php
	//make connection with database
	$link = mysqli_connect('localhost','id15006331_sauvik','\&TuTXB+Iy#d5iRo','id15006331_test');
	// Check connection
	if($link === false) {
    	die("ERROR: Could not connect. " . mysqli_connect_error());
	}
?>
