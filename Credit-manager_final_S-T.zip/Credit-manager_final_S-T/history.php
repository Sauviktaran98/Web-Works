<?php
    require_once('db_connect.php'); //connect to database

    $query = "select * from transfers";
    $result = mysqli_query($link,$query);

?>

<html>
	<head>
        <title>Credit Management History</title>
         <meta name="viewport" content="width=device-width, initial-scale=1">
       <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
      <link rel="stylesheet" href="css/style1.css">
      <link rel="stylesheet" href="css/himage.css">
      <link rel="stylesheet" href="css/ff.css">
     
      <link rel="stylesheet" href="css/table.css">
      <link rel="stylesheet" href="css/btn.css">
        
    </head>

    <body style="background: linear-gradient(0deg, rgba(233,221,213,1) 5%, rgba(233,245,161,1) 24%, rgba(198,211,255,1) 81%, rgba(236,221,224,1) 100%);">
        <div class="topnav" id="myTopnav" style="background-color: #393A3A  ;">
    <a href="index.html" class="active">Home</a>
  
    <a href="#contact">Contact</a>
    
    <a href="#about">About</a>
    <a href="javascript:void(0);" class="icon" onclick="myFunction()">&#9776;</a>
  </div>
    <p style="text-align:center;font-size: 25px;font-family:courier;">Recent Transactions</p>
        <table class="redTable" style="margin-top: 20px;">
			<thead>
				<tr>
                    <th>S No.</th>
    				<th>From_User</th>
    				<th>To_User</th>
    				<th>Credit Amount</th>
				</tr>
			</thead>

            <!--fetch and display data from MySQL-->
            <?php
                $i=1;

                while($row = mysqli_fetch_array($result)) {
                    echo "<tr>";
                    echo "<td>" . $i . "</td>";
                    echo "<td>" . $row["from_user"] . "</td>";
                    echo "<td>" . $row["to_user"] . "</td>";
                    echo "<td>" . $row["credits_tr"] . "</td>";
                    
                    echo "</tr>";
                    ++$i;
                }
            ?>

        </table>
        <br>
        <a  type ="button" class="button" href="users.php" > <span >Return</span></a>
        <br>
        <br>
        <br>
        <br>
        <br>
         <footer>
    
    <div style="position: fixed;
   left: 0;
   bottom: 0;
   width: 100%;
   height: 58px;

   background-color:  rgba(136, 134, 248, 0.904);
   color: white;
   text-align: center;">
    <p>Copyright &#169; Credit ManagementSytem</p>
   </div>
    </footer>
<script src="js/js1.js"></script>
    </body>
</html>
