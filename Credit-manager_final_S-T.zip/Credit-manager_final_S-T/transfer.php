<?php
    require_once('db_connect.php'); //connect to database

    $Name = $_GET['Name'];
    $query = "select * from registration where Name='" . $Name . "'";
    $result = mysqli_query($link,$query);
    $row = mysqli_fetch_array($result);
    
    $query = "select Name from registration where Name<>'" . $row['Name'] . "'";
    $result = mysqli_query($link,$query);

    if(isset($_POST['transfer'])) {
        if($_POST['credits_tr'] > $row['Credit']) {
            echo "Credits transferred cannot be more than " . $row['Credit'] . "<br>";
        }

        else {
            $query = "update registration set Credit=Credit-" . $_POST['credits_tr'] . " where Name='" . $row['Name'] . "'";
            mysqli_query($link,$query);

            $query = "update registration set Credit=Credit+" . $_POST['credits_tr'] . " where Name='" . $_POST['to_user'] . "'";
            mysqli_query($link,$query);

            $query = "insert into transfers values('" . $row['Name'] . "','" . $_POST['to_user'] . "'," . $_POST['credits_tr'] . ")";
            mysqli_query($link,$query);

            header("Location: thanks.html");
        }
    }
?>

<html>
    <head>
        <title>Transfer Credits</title>
        
        <link rel="stylesheet" href="css/btn.css">


    </head>

    <body style="background: #ECE9E6;  /* fallback for old browsers */
background: -webkit-linear-gradient(to right, #FFFFFF, #ECE9E6);  /* Chrome 10-25, Safari 5.1-6 */
background: linear-gradient(to right, #FFFFFF, #ECE9E6); /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */
">
       
        <div class="container" style="width: 39%;margin-left: 30vw;">
        <div style="margin-left: 110px;
         margin-bottom: 30px;
        font-size: 25;margin-top: 20px;font-family:Lucida Bright;
        ">
        Welcome <?php echo $row['Name'] ?>
        </div>
        <div style="margin-left: 221px;">
        Available Balance: <?php echo $row['Credit'] ?>
        </div>
        
        
        <form action="#" method="post" style="height: 350px;
    padding-left: 157px;
    width: 405px;
    /* margin-right: 426px; */
    margin-top: 10px;
    padding-top: 29px;
    margin-left: -35px;
    background: #1D976C;  /* fallback for old browsers */
background: -webkit-linear-gradient(to right, #93F9B9, #1D976C);  /* Chrome 10-25, Safari 5.1-6 */
background: linear-gradient(to right, #93F9B9, #1D976C); /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */

">
            
                
               
               <div class="form-group">
                <label >Credits:</label>
                <input type="number" name="credits_tr" min =1 value=1 required>
               </div>
               <br>
                <div class="form-group">
               <label >Transfer To:</label>
                <select name="to_user" required>
                    <option value =""></option>

                  <?php
                        while($tname = mysqli_fetch_array($result))
                         {
                            echo "<option value='" . $tname['Name'] . "'>" . $tname['Name'] . "</option>";
                        }
                    ?>

                </select>
                </div>
                <br>
                <div class="form-group">

                <button class="button" style="vertical-align: middle;
               
                width: 239px;
                margin-left: 5px;
                padding-right: 0px;" type="submit" name="transfer" value="Transfer" > <span>Transfer</span></button>
                 </div>
                 <div class="form-group">
              
                 <a  type ="button" class="button" href="users.php" > <span >Cancel</span></a>
                </div>
             
                
            </div>
            
        </form>
    </div>
    <footer>
    
    <div style="position: fixed;
   left: 0;
   bottom: 0;
   width: 100%;
   height: 50px;
   background-color:  rgba(136, 134, 248, 0.904);
   color: white;
   text-align: center;">
    <p>Copyright &#169; Credit ManagementSytem</p>
   </div>
    </footer>
      
    
    </body>
</html>
