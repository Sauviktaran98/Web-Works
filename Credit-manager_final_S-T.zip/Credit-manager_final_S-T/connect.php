<?php
	$Name = $_POST['Name'];
	$Credit = $_POST['Credit'];
	
	$email = $_POST['email'];
	

	// Database connection
	$conn = new mysqli('localhost','id15006331_sauvik','\&TuTXB+Iy#d5iRo','id15006331_test');
	if($conn->connect_error){
		echo "$conn->connect_error";
		die("Connection Failed : ". $conn->connect_error);
	} else {
		$stmt = $conn->prepare("insert into registration(Name,  Credit, email) values(?, ?, ?)");
		$stmt->bind_param("sis", $Name, $Credit,  $email);
		$execval = $stmt->execute();
		
		
	    $stmt->close();
		$conn->close();
		header("Location:useradd.html");
	}
?>